package com.example.sensorssample;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements SensorEventListener,
		LocationListener {

	private TextView axisX;
	private TextView axisY;
	private TextView axisZ;
	private TextView latitude;
	private TextView longitude;

	private SensorManager sensorManager;
	private LocationManager locationManager;
	private String provider;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		axisX = (TextView) findViewById(R.id.axis_x);
		axisY = (TextView) findViewById(R.id.axis_y);
		axisZ = (TextView) findViewById(R.id.axis_z);

		latitude = (TextView) findViewById(R.id.latitude);
		longitude = (TextView) findViewById(R.id.longitude);

		sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

		// LOCALIZACAO do GPS
		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE); // FINE(GPS)
		provider = locationManager.getBestProvider(criteria, true);
		locationManager.requestLocationUpdates(provider, 400, 1, this);
		Location location = locationManager.getLastKnownLocation(provider);
		

		if (location != null) {
			System.out.println("Provider " + provider + " selecioado.");
			onLocationChanged(location);
		} else {
			latitude.setText("Latitude indispon�vel!");
			longitude.setText("Longitude indispon�vel!");
		}

	}

	@Override
	protected void onResume() {
		super.onResume();
		locationManager.requestLocationUpdates(provider, 400, 1, this);
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void onStart() {
		super.onStart();

		// SENSOR DO GIROSCOPIO
		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION),
				SensorManager.SENSOR_DELAY_UI);

		sensorManager.registerListener(this,
				sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY),
				SensorManager.SENSOR_DELAY_UI);
		

		locationManager.requestLocationUpdates(provider, 400, 1, this);

	}

	@Override
	protected void onStop() {
		super.onStop();
		sensorManager.unregisterListener(this);
		locationManager.removeUpdates(this);
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		if (event.sensor.getType() == Sensor.TYPE_PROXIMITY)
			axisX.setText("cm: " + event.values[0]);

		axisX.setText("X: " + event.values[0]);
		axisY.setText("Y: " + event.values[1]);
		axisZ.setText("Z: " + event.values[2]);

	}

	@Override
	public void onLocationChanged(Location location) {
		int lat = (int) (location.getLatitude());
		int lng = (int) (location.getLongitude());
		latitude.setText(String.valueOf(lat));
		longitude.setText(String.valueOf(lng));
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onProviderEnabled(String provider) {
		Toast.makeText(this, "Enabled new provider " + provider,
				Toast.LENGTH_SHORT).show();

	}

	@Override
	public void onProviderDisabled(String provider) {
		Toast.makeText(this, "Disabled provider " + provider,
				Toast.LENGTH_SHORT).show();
	}

}
