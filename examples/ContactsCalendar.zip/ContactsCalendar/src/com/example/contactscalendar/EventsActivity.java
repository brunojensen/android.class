package com.example.contactscalendar;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Events;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

@SuppressLint("NewApi")
public class EventsActivity extends ListActivity {

    private static final DateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy", new Locale("pt-BR"));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        final ContentResolver contentResolver = getContentResolver();
        final Cursor cursor = contentResolver.query(CalendarContract.Events.CONTENT_URI, null, null, null, null);
        final CursorAdapter adapter = createCursorAdapter(contentResolver, cursor);
        setListAdapter(adapter);
    }

    @SuppressWarnings("deprecation")
    private CursorAdapter createCursorAdapter(final ContentResolver contentResolver, final Cursor cursor) {
        return new CursorAdapter(getApplicationContext(), cursor) {
            @Override
            public View newView(Context context, Cursor cursor, ViewGroup parent) {
                return getLayoutInflater().inflate(R.layout.events_item, parent, false);
            }

            @Override
            public void bindView(View view, Context context, Cursor cursor) {
                TextView titulo = (TextView) view.findViewById(R.id.titulo);
                titulo.setText(cursor.getString(cursor.getColumnIndex(CalendarContract.Events.TITLE)));
                TextView data = (TextView) view.findViewById(R.id.data);
                data.setText(SIMPLE_DATE_FORMAT.format(new Date(cursor.getLong(cursor.getColumnIndex(CalendarContract.Events.DTSTART)))));
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.events, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void newEvent() {

    }

    public void newEventViaIntent() {
        final Intent intent = new Intent(Intent.ACTION_EDIT);
        intent.putExtra(Events.TITLE, "Pascoa");
        intent.putExtra(Events.DESCRIPTION, "Feliz Pascoa");

        final GregorianCalendar calDate = new GregorianCalendar(2014, 04, 20);
        intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, calDate.getTimeInMillis());
        intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, calDate.getTimeInMillis());

        intent.putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, true);

        intent.setData(CalendarContract.Events.CONTENT_URI);
        startActivity(intent);
    }
}
