package com.example.contactscalendar;

import android.app.ListActivity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class ContactsActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        final ContentResolver contentResolver = getContentResolver();
        final Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        final CursorAdapter adapter = createCursorAdapter(contentResolver, cursor);
        setListAdapter(adapter);
    }

    @SuppressWarnings("deprecation")
    private CursorAdapter createCursorAdapter(final ContentResolver contentResolver, final Cursor cursor) {
        return new CursorAdapter(getApplicationContext(), cursor) {
            @Override
            public View newView(Context context, Cursor cursor, ViewGroup parent) {
                return getLayoutInflater().inflate(R.layout.contacts_item, parent, false);
            }

            @Override
            public void bindView(View view, Context context, Cursor cursor) {
                final String contact_id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                TextView nome = (TextView) view.findViewById(R.id.nome);
                nome.setText(cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME)));
                TextView telefone = (TextView) view.findViewById(R.id.telefone);
                telefone.setText(loadPhone(contact_id));
                TextView email = (TextView) view.findViewById(R.id.email);
                email.setText(loadEmail(contact_id));
            }

            private String loadPhone(String contact_id) {
                String retorno = "";
                Cursor cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                                                      ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                                      new String[] { contact_id }, null);
                if (cursor.moveToNext()) {
                    retorno = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                }
                cursor.close();
                return retorno;
            }

            private String loadEmail(String contact_id) {
                String retorno = "";
                Cursor cursor = contentResolver.query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                                                      ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                                                      new String[] { contact_id }, null);
                if (cursor.moveToNext()) {
                    retorno = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Email.DATA));
                }
                cursor.close();
                return retorno;
            }
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.contacts, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
