/** Automatically generated file. DO NOT MODIFY */
package com.example.contactscalendar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}