/** Automatically generated file. DO NOT MODIFY */
package com.example.androidtoolstest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}