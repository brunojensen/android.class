package com.example.androidtoolstest;

import java.util.List;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import br.com.bea.androidtools.api.android.AbstractAsyncTask;
import br.com.bea.androidtools.api.storage.sqlite.EntityStorage;
import com.example.androidtoolstest.adapter.TarefaListAdapter;
import com.example.androidtoolstest.model.Tarefa;
import com.example.androidtoolstest.service.TarefaService;

public class MainActivity extends ListActivity {

    private TarefaListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EntityStorage.getInstance().init(getApplicationContext(), "TarefasDb", Tarefa.class);
        adapter = new TarefaListAdapter(getLayoutInflater());
        setListAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        new AbstractAsyncTask<Tarefa>(new TarefaService()) {
            @Override
            public void resultCallback(List<Tarefa> tarefas) {
                adapter.clear();
                adapter.addAll(tarefas);
            }
        }.execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
