package com.example.androidtoolstest.model;

import java.util.Date;
import br.com.bea.androidtools.api.model.Entity;
import br.com.bea.androidtools.api.model.annotations.Column;
import br.com.bea.androidtools.api.model.annotations.Column.Type;
import br.com.bea.androidtools.api.model.annotations.DateFormat;
import br.com.bea.androidtools.api.model.annotations.Id;
import br.com.bea.androidtools.api.model.annotations.Metadata;
import br.com.bea.androidtools.api.model.annotations.Table;

@Table(name = "tarefa")
public class Tarefa extends Entity<Long> {

    private static final long serialVersionUID = 1L;

    @Id(autoincrement = true)
    @Column(name = "id", type = Type.NUMERIC)
    private Long id;

    @Metadata("Data")
    @DateFormat(pattern = "dd/MM/yyyy")
    @Column(name = "data", type = Type.TEXT)
    private Date data;

    @Metadata("Descricao")
    @Column(name = "descricao", type = Type.TEXT)
    private String descricao;

    @Metadata("Responsavel")
    @Column(name = "responsavel", type = Type.TEXT)
    private String responsavel;

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

}
