package com.example.androidtoolstest.service;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import br.com.bea.androidtools.api.proxy.HttpProxy;
import br.com.bea.androidtools.api.service.Service;
import br.com.bea.androidtools.api.storage.sqlite.EntityQuery;
import br.com.bea.androidtools.api.storage.sqlite.EntityStorage;
import br.com.bea.androidtools.api.storage.sqlite.Restriction;
import com.example.androidtoolstest.model.Tarefa;

public class TarefaService implements Service<Tarefa> {
    private static final String URL_REST = "http://www.cswebdesign.com.br/testeandroid.aspx";

    @Override
    public Tarefa find(Tarefa tarefa) {
        return EntityStorage.getInstance().find(tarefa);
    }

    @Override
    public List<Tarefa> search(Tarefa tarefa) {
        if(count(tarefa) == 0) return searchRemote();
        final EntityQuery query = EntityQuery.select().from(Tarefa.class);
        if (null != tarefa && null != tarefa.getResponsavel())
            query.where(Restriction.eq("responsavel", tarefa.getResponsavel()));
        return EntityStorage.getInstance().search(query);
    }

    private  List<Tarefa> searchRemote() {
        final List<Tarefa> list = new ArrayList<Tarefa>();
        try {
            list.addAll(new HttpProxy<Tarefa>(Tarefa.class).connectTo(new URL(URL_REST))
            .doGet());
            for(Tarefa tarefa : list) {
                EntityStorage.getInstance().persist(tarefa);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } 
        return list;
    }

    public Long count(Tarefa tarefa) {
        final EntityQuery query = EntityQuery.select().from(Tarefa.class);
        if (null != tarefa && null != tarefa.getResponsavel())
            query.where(Restriction.eq("responsavel", tarefa.getResponsavel()));
        return EntityStorage.getInstance().count(query);
    }
    
}
