package com.example.androidtoolstest.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import br.com.bea.androidtools.api.android.AbstractListAdapter;
import com.example.androidtoolstest.model.Tarefa;

public class TarefaListAdapter extends AbstractListAdapter<Tarefa> {

    private class TarefaViewHolder {
        TextView data;
        TextView descricao;
        TextView responsavel;
    }

    public TarefaListAdapter(final LayoutInflater inflater) {
        super(inflater);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout layout = (LinearLayout) convertView;
        TarefaViewHolder holder;

        if (layout == null) {
//            layout = (LinearLayout) inflater.inflate(R.layout.list_item, null);
            holder = new TarefaViewHolder();
//            holder.data = (TextView) layout.findViewById(R.id.item_data);
//            holder.descricao = (TextView) layout.findViewById(R.id.item_descricao);
//            holder.responsavel = (TextView) layout.findViewById(R.id.item_responsavel);
//            layout.setTag(holder);
        } else {
            holder = (TarefaViewHolder) layout.getTag();
        }

        final Tarefa item = (Tarefa) getItem(position);
        holder.data.setText(item.getData().toString());
        holder.descricao.setText(item.getDescricao());
        holder.responsavel.setText(item.getResponsavel());

        return layout;
    }

}
