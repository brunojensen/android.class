package com.example.customadapter;

import java.util.ArrayList;
import java.util.List;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

    final class ViewHolder {
        TextView nome;
        TextView categoria;
        TextView valor;
    }

    protected final LayoutInflater inflater;
    private List<Item> itens = new ArrayList<Item>(0);

    public CustomAdapter(final LayoutInflater inflater) {
        this.inflater = inflater;
    }

    public final void add(final Item element) {
        this.itens.add(element);
        notifyDataSetChanged();
    }

    public final void addAll(final List<Item> list) {
        this.itens.addAll(list);
        notifyDataSetChanged();
    }

    public final void clear() {
        itens.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return itens.size();
    }

    @Override
    public Object getItem(int position) {
        return itens.get(position);
    }

    @Override
    public long getItemId(int position) {
        final Item item = (Item) getItem(position);
        return item.getId();
    }

    @Override
    public synchronized View getView(final int position,
                                     final View convertView,
                                     final ViewGroup parent) {
        LinearLayout layout = (LinearLayout) convertView;
        ViewHolder holder;

        if (layout == null) {
            layout = (LinearLayout) inflater.inflate(R.layout.list_item, null);
            holder = new ViewHolder();
            holder.nome = (TextView) layout.findViewById(R.id.item_name);
            holder.categoria = (TextView) layout.findViewById(R.id.item_category);
            holder.valor = (TextView) layout.findViewById(R.id.item_value);
            layout.setTag(holder);
        } else {
            holder = (ViewHolder) layout.getTag();
        }

        final Item item = (Item) getItem(position);
        holder.nome.setText(item.getNome());
        holder.categoria.setText(item.getCategoria());
        holder.valor.setText(item.getValor().toString());

        return layout;
    }

}
