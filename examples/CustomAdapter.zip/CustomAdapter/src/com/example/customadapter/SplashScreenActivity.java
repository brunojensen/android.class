package com.example.customadapter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SplashScreenActivity extends Activity {

    @Override
    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_splash_screen);

        final SplashScreenActivity sPlashScreen = this;

        final ImageView splashImageView = (ImageView) findViewById(R.id.splash_image);
        final ImageView splashImageViewLogo = (ImageView) findViewById(R.id.splash_image_logo);

        splashImageView.setVisibility(View.VISIBLE);
        splashImageViewLogo.setVisibility(View.VISIBLE);

        final Animation anime = AnimationUtils.loadAnimation(sPlashScreen,
                                                             R.anim.appear);
        splashImageView.startAnimation(anime);
        splashImageViewLogo.startAnimation(anime);

        anime.setAnimationListener(new AnimationListener() {
            @Override
            public void onAnimationEnd(final Animation animation) {

                final int value = (int) (1 + Math.random() * 6);
                int animationType = 0;

                switch (value) {
                    case 1:
                        animationType = R.anim.fade_out;
                        break;
                    case 2:
                        animationType = R.anim.push_down_out;
                        break;
                    case 3:
                        animationType = R.anim.disappear;
                        break;
                    case 4:
                        animationType = R.anim.slide_out_right;
                        break;
                    case 5:
                        animationType = R.anim.push_down_out;
                        break;
                    default:
                        animationType = R.anim.slide_out_right;
                        break;
                }

                final Animation slideToRightOut = AnimationUtils
                    .loadAnimation(SplashScreenActivity.this, animationType);
                splashImageView.startAnimation(slideToRightOut);
                splashImageView.setVisibility(View.INVISIBLE);
                splashImageViewLogo.startAnimation(slideToRightOut);
                splashImageViewLogo.setVisibility(View.INVISIBLE);

                slideToRightOut.setAnimationListener(new AnimationListener() {

                    @Override
                    public void onAnimationEnd(final Animation animation) {
                        finish();
                        final Intent intent = new Intent();
                        intent.setClass(sPlashScreen, MainActivity.class);
                        startActivity(intent);

                    }

                    @Override
                    public void onAnimationRepeat(final Animation animation) {
                    }

                    @Override
                    public void onAnimationStart(final Animation animation) {
                    }
                });
            }

            @Override
            public void onAnimationRepeat(final Animation arg0) {
            }

            @Override
            public void onAnimationStart(final Animation arg0) {
            }
        });

    }

}
