package com.example.customadapter;

import java.math.BigDecimal;
import java.util.Arrays;
import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
         * LayoutInflater:
         * Instancia um layout dentro da sua correspondente View.
         * Não deve ser instanciado diretamento. Deve-se utilizar o exemplo abaixo, 
         * onde será carregada uma instancia já vinculada ao contexto de execução
         * da aplicação. 
         */
        final CustomAdapter adapter = new CustomAdapter((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE));
        adapter.addAll(Arrays.asList(
            new Item(1l, "Item 1", "A", BigDecimal.ONE)
            , new Item(2l, "Item 2", "B", BigDecimal.ONE)
            , new Item(3l, "Item 3", "C", BigDecimal.ONE)
            ));
        setListAdapter(adapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        Item item = (Item) getListAdapter().getItem(position);
        Toast.makeText(this, item.getNome() + " selected", Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
