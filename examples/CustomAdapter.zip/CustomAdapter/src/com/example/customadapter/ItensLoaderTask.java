package com.example.customadapter;

import java.util.List;
import android.os.AsyncTask;

public class ItensLoaderTask extends AsyncTask<Item, Long, List<Item>> {

    @Override
    protected List<Item> doInBackground(Item... params) {
        return null;
    }

}
