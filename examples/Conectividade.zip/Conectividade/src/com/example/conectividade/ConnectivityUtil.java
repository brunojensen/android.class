package com.example.conectividade;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class ConnectivityUtil {

    public static final boolean hasConnectivity(final Context context, final int... networkTypes) {
        final ConnectivityManager connectivity = (ConnectivityManager) context
            .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (networkTypes.length > 0)
            for (final int networkType : networkTypes)
                if (ConnectivityManager.isNetworkTypeValid(networkType))
                    return hasConnectivity(connectivity.getNetworkInfo(networkType));
        return hasConnectivity(connectivity.getActiveNetworkInfo());
    }

    private static boolean hasConnectivity(final NetworkInfo info) {
        return null != info && info.isAvailable() && info.isConnected();
    }

}
