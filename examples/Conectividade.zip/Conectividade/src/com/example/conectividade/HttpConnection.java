package com.example.conectividade;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

public class HttpConnection {

    private HttpURLConnection connection;
    private InputStream input;
    private OutputStream output;

    public void close() {
        try {
            if (null != input) input.close();
            if (null != output) output.close();
            if (null != connection) connection.disconnect();
        } catch (final IOException e) {
            e.printStackTrace();
        }
    }

    public HttpConnection connect(final Properties properties) {
        try {
            if (properties.containsKey("url_connection") && properties.containsKey("method")) {
                connection = (HttpURLConnection) new URL(properties.getProperty("url_connection")).openConnection();
                connection.setRequestMethod(properties.getProperty("method"));
            }
        } catch (final Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    public boolean isConnected() {
        return null != connection;
    }

    public String request(byte[] data) throws Exception {
        if (null == connection) throw new Exception("Conexao nao realizada!");
        try {
            if (null != data) {
                connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(data.length);
                output = connection.getOutputStream();
                output.write(data);
                output.flush();
            }
            input = connection.getInputStream();
            final StringBuilder sb = new StringBuilder();
            if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
                String line = null;
                while ((line = reader.readLine()) != null)
                    sb.append(line);
                return sb.toString();
            }
        } catch (final Exception e) {
            throw new Exception(e.getLocalizedMessage());
        }
        return new String();
    }

}
