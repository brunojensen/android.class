package com.example.conectividade;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.ProtocolVersion;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.params.CoreProtocolPNames;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class HttpClientConnection {

    public final static String RESPONSE = "com.example.conectividade.RESPONSE";
    private final Handler handler;
    private final URL url;
    private static final DefaultHttpClient client;
    static {
        final HttpParams params = new BasicHttpParams();
        params.setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);
        params.setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET, HTTP.UTF_8);
        params.setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 15000);
        params.setParameter(CoreConnectionPNames.STALE_CONNECTION_CHECK, false);
        final SchemeRegistry schemeRegistry = new SchemeRegistry();
        schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
        schemeRegistry.register(new Scheme("https", SSLSocketFactory.getSocketFactory(), 443));
        final ThreadSafeClientConnManager cm = new ThreadSafeClientConnManager(params, schemeRegistry);
        client = new DefaultHttpClient(cm, params);
    }
    private final BasicHttpResponse errorResponse = new BasicHttpResponse(new ProtocolVersion("HTTP_ERROR", 1, 1),
                                                                          500,
                                                                          "ERROR");
    private ResponseHandler<String> responseHandler = new ResponseHandler<String>() {
        @Override
        public String handleResponse(HttpResponse response) {
            final HttpEntity httpEntity = response.getEntity();
            if (null != httpEntity)
                try {
                    final StringBuilder builder = new StringBuilder();
                    final BufferedReader reader = new BufferedReader(new InputStreamReader(httpEntity.getContent(),
                                                                                           "utf-8"));
                    String line = null;
                    while ((line = reader.readLine()) != null)
                        builder.append(line);
                    if(null != handler) {
                        final Message message = handler.obtainMessage();
                        message.setData(new Bundle());
                        message.getData().putString(RESPONSE, builder.toString());
                    }
                    return builder.toString();
                } catch (final Exception e) {
                    e.printStackTrace();
                }
            return null;
        }
    };

    public HttpClientConnection(final URL url, final Handler handler) {
        this.url = url;
        this.handler = handler;
    }

    public void doPost(final Map<String, String> parameters) {
        try {
            final HttpPost method = new HttpPost(url.toString());
            final List<NameValuePair> adjustParams = adjustParameters(parameters);
            if (!adjustParams.isEmpty()) try {
                method.setEntity(new UrlEncodedFormEntity(adjustParams, HTTP.UTF_8));
            } catch (final UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            client.execute(method, responseHandler);
        } catch(Exception e) {
            errorResponse.setReasonPhrase(e.getMessage());
            try {
                this.responseHandler.handleResponse(errorResponse);
            } catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public void doGet() throws Exception {
        try {
            final HttpGet method = new HttpGet(url.toString());
            client.execute(method, responseHandler);
        } catch(Exception e) {
            errorResponse.setReasonPhrase(e.getMessage());
            try {
                this.responseHandler.handleResponse(errorResponse);
            } catch (final Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private List<NameValuePair> adjustParameters(final Map<String, String> parameters) {
        final List<NameValuePair> list = new ArrayList<NameValuePair>(0);
        for (final String key : parameters.keySet())
            list.add(new BasicNameValuePair(key, parameters.get(key)));
        return list;
    }
}
