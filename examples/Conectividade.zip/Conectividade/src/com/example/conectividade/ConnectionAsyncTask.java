package com.example.conectividade;

import android.os.AsyncTask;

public class ConnectionAsyncTask extends AsyncTask<Void, Integer, String> {

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected String doInBackground(Void... params) {
        return null;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
    }
}
