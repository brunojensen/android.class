package com.example.conectividade;

import java.util.Properties;
import android.os.AsyncTask;
import android.widget.TextView;

public class ConnectionAsyncTask extends AsyncTask<String, Integer, String> {

    private final HttpConnection connection = new HttpConnection();
    private final MainActivity mainActivity;

    public ConnectionAsyncTask(final MainActivity mainActivity) {
        this.mainActivity = mainActivity;
    }

    @Override
    protected String doInBackground(String... params) {
        String response = null;
        if(params.length == 2) {
            final Properties properties = new Properties();
            properties.put("url_connection", params[0]);
            properties.put("method", params[1]);
            try {
                response = connection.connect(properties)
                                     .request(null);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connection.close();
            }
        }
        return response;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
        ((TextView) mainActivity.findViewById(R.id.connection))
                                .setText(result);
    }
}
