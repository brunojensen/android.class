package com.example.broadcast;

import java.io.File;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static int CAMERA_REQUEST = 1666;
    private Uri mImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickTirarFoto(final View v) {
        final Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File photo = null;

        try {
            // picture
            photo = createTemporaryFile("picture", ".jpg");
            photo.delete();
        } catch (final Exception e) {
            System.out.println("nao pode criar foto");
        }
        mImageUri = Uri.fromFile(photo);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri);

        startActivityForResult(cameraIntent, CAMERA_REQUEST);
    }

    private File createTemporaryFile(final String part, final String ext) throws Exception {
        File tempDir = Environment.getExternalStorageDirectory();
        tempDir = new File(tempDir.getAbsolutePath() + "/.temp/");
        if (!tempDir.exists()) {
            tempDir.mkdir();
        }
        return File.createTempFile(part, ext, tempDir);
    }

    private void grabImage(final ImageView imageView) {
        getContentResolver().notifyChange(mImageUri, null);
        final ContentResolver cr = getContentResolver();
        Bitmap bitmap;
        try {
            bitmap = android.provider.MediaStore.Images.Media.getBitmap(cr, mImageUri);
            imageView.setTag(bitmap);
            imageView.setImageBitmap(bitmap);
        } catch (final Exception e) {
            Toast.makeText(this, "Falha ao carregar foto tirada.", Toast.LENGTH_SHORT).show();
        }

    }

    @SuppressLint("ShowToast") @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {

        if (requestCode == CAMERA_REQUEST) {
            if (resultCode == RESULT_OK) {
                final ImageView imageView = (ImageView) findViewById(R.id.imageView1);

                grabImage(imageView);

                imageView.setVisibility(View.VISIBLE);

                imageView.setMaxHeight(260);
                imageView.setMaxWidth(260);

            } else if (resultCode == RESULT_CANCELED) {
                System.out.println("Usuario cancelou!");
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
