/** Automatically generated file. DO NOT MODIFY */
package com.example.temperatureconverter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}