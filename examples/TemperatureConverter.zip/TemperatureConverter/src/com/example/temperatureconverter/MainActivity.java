package com.example.temperatureconverter;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
    private EditText text;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (EditText) findViewById(R.id.editText1);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button1:
                RadioButton celsiusButton = (RadioButton) findViewById(R.id.radio0);
                RadioButton fahrenheitButton = (RadioButton) findViewById(R.id.radio1);
                if (text.getText().length() == 0) {
                    Toast.makeText(this, "Campo texto obrigatório.", Toast.LENGTH_LONG).show();
                    return;
                }
                float inputValue = Float.parseFloat(text.getText().toString());
                if (celsiusButton.isChecked()) {
                    String valor = String.valueOf(ConverterUtil.convertFahrenheitToCelsius(inputValue));
                    text.setText(valor);
                    celsiusButton.setChecked(false);
                    fahrenheitButton.setChecked(true);
                    sendToast(valor + " Celsius");
                } else {
                    String valor = String.valueOf(ConverterUtil.convertCelsiusToFahrenheit(inputValue));
                    text.setText(valor);
                    fahrenheitButton.setChecked(false);
                    celsiusButton.setChecked(true);
                    sendToast(valor + " Fahrenheit");
                }
                break;
        }
    }

    private void sendToast(String valor) {
        Toast toast = Toast.makeText(this, valor, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }
}
