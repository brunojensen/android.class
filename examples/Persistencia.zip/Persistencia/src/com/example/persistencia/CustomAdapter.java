package com.example.persistencia;

import java.util.ArrayList;
import java.util.List;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {

    final class ViewHolder {
        TextView id;
        TextView item;
        TextView content;
    }

    protected final LayoutInflater inflater;
    private List<Post> itens = new ArrayList<Post>(0);

    public CustomAdapter(final LayoutInflater inflater) {
        this.inflater = inflater;
    }

    public final void add(final Post element) {
        this.itens.add(element);
        notifyDataSetChanged();
    }

    public final void addAll(final List<Post> list) {
        this.itens.addAll(list);
        notifyDataSetChanged();
    }

    public final void clear() {
        itens.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return itens.size();
    }

    @Override
    public Object getItem(int position) {
        return itens.get(position);
    }

    @Override
    public long getItemId(int position) {
        final Post item = (Post) getItem(position);
        return item.getId();
    }

    @Override
    public synchronized View getView(final int position,
                                     final View convertView,
                                     final ViewGroup parent) {
        LinearLayout layout = (LinearLayout) convertView;
        ViewHolder holder;

        if (layout == null) {
            layout = (LinearLayout) inflater.inflate(R.layout.list_item, null);
            holder = new ViewHolder();
            holder.id= (TextView) layout.findViewById(R.id.id);
            holder.item = (TextView) layout.findViewById(R.id.item);
            holder.content = (TextView) layout.findViewById(R.id.content);
            layout.setTag(holder);
        } else {
            holder = (ViewHolder) layout.getTag();
        }

        final Post post = (Post) getItem(position);
        holder.id.setText(post.getId().toString());
        holder.item.setText(post.getTitle());
        holder.content.setText(post.getContent());

        return layout;
    }

}
