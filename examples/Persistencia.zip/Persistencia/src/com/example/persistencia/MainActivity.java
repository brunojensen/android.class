package com.example.persistencia;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String PREFS_NAME = "PERSISTENCIA";
    private BlogLiteHelper blogLiteHelper;
    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        blogLiteHelper = new BlogLiteHelper(getApplicationContext());
        preferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        preferences.edit().putInt("databaseVersion", 1);

        if(null != getIntent()) {
            final Intent intent = getIntent();
//            if(intent.getExtras().containsKey("post")) {
//                Post post = (Post) intent.getExtras().getSerializable("post");
//                ((EditText) findViewById(R.id.title)).setText(post.getTitle());
//                ((EditText) findViewById(R.id.content)).setText(post.getContent());
//            }
        }
    }

    public void savePost(View view) {
        final Post post = new Post();
        post.setTitle(getValue((EditText) findViewById(R.id.title)));
        post.setContent(getValue((EditText) findViewById(R.id.content)));
        blogLiteHelper.save(post);

        Toast.makeText(getApplicationContext()
                       , "Salvo com sucesso!"
                       , Toast.LENGTH_LONG)
                       .show();
        startActivity(new Intent(this, ListActivity.class));
    }

    public void back(View view) {
        startActivity(new Intent(this, ListActivity.class));
    }

    private String getValue(EditText editText) {
        if(null != editText)
            return editText.getText().toString();
        return "";
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

}
