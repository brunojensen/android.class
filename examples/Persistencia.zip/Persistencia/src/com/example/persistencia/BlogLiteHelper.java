package com.example.persistencia;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

public final class BlogLiteHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BLOGGER";
    private static final String BLOG_TABLE = "POST";

    public BlogLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final StringBuilder builder = new StringBuilder();
        builder.append(" CREATE TABLE IF NOT EXISTS ")
               .append(BLOG_TABLE).append(" ( ")
               .append(" ID INTEGER PRIMARY KEY, ")
               .append(" TITLE TEXT, ")
               .append(" CONTENT TEXT ) ");
        db.execSQL(builder.toString());
    }

    public void save(Post post) {
        final ContentValues values = new ContentValues();
        values.put("ID", post.getId());
        values.put("TITLE", post.getTitle());
        values.put("CONTENT", post.getContent());
        final SQLiteDatabase database = getWritableDatabase();
        database.insert(BLOG_TABLE, null, values);
        close();
    }

    public void update(Post post) {
        final ContentValues values = new ContentValues();
        values.put("TITLE", post.getTitle());
        values.put("CONTENT", post.getContent());
        final SQLiteDatabase database = getWritableDatabase();
        database.update(BLOG_TABLE, values, "ID = ? ", new String[] { post.getId().toString() });
        close();
    }

    public void delete(final Long id) {
        final SQLiteDatabase database = getWritableDatabase();
        database.delete(BLOG_TABLE, "ID = ? ", new String[] { id.toString() });
        close();
    }

    public List<Post> findAll() {
        final List<Post> list = new ArrayList<Post>(0);
        final SQLiteDatabase database = getReadableDatabase();
        final Cursor cursor = database.query(BLOG_TABLE
                       , new String[] { "ID", "TITLE", "CONTENT" } //columns
                       , null //selection
                       , null //selectionArgs
                       , null //groupBy
                       , null //having
                       , null //orderBy
                       );
        if (cursor.moveToFirst())
            do
                try {
                    final Post post = new Post();
                    post.setId(cursor.getLong(cursor.getColumnIndex("ID")));
                    post.setTitle(cursor.getString(cursor.getColumnIndex("TITLE")));
                    post.setContent(cursor.getString(cursor.getColumnIndex("CONTENT")));
                    list.add(post);
                } catch (final Exception e) {
                    throw new SQLiteException(e.getMessage());
                }
            while (cursor.moveToNext());
        cursor.close();
        close();
        return list;
    }

    public Post findById(final Long id) {
        final List<Post> list = new ArrayList<Post>(0);
        final SQLiteDatabase database = getReadableDatabase();
        final Cursor cursor = database.query(BLOG_TABLE
                       , new String[] { "ID", "TITLE", "CONTENT" } //columns
                       , " ID = ? " //selection
                       , new String[] { id.toString() } //selectionArgs
                       , null //groupBy
                       , null //having
                       , null //orderBy
                       );
        if (cursor.moveToFirst())
            do
                try {
                    final Post post = new Post();
                    post.setId(cursor.getLong(cursor.getColumnIndex("ID")));
                    post.setTitle(cursor.getString(cursor.getColumnIndex("TITLE")));
                    post.setContent(cursor.getString(cursor.getColumnIndex("CONTENT")));
                    list.add(post);
                } catch (final Exception e) {
                    throw new SQLiteException(e.getMessage());
                }
            while (cursor.moveToNext());
        cursor.close();
        close();
        final Iterator<Post> iterator = list.iterator();
        return iterator.hasNext() ? iterator.next() : null;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

}
