package com.example.persistencia;

import java.util.List;
import android.os.AsyncTask;

public class BlogLoaderTask extends AsyncTask<Void, Void, List<Post>> {

    private CustomAdapter adapter;
    private BlogLiteHelper blogLiteHelper;

    public BlogLoaderTask(BlogLiteHelper blogLiteHelper, CustomAdapter adapter) {
        this.blogLiteHelper = blogLiteHelper;
        this.adapter = adapter;
    }

    @Override
    protected List<Post> doInBackground(Void... params) {
        return blogLiteHelper.findAll();
    }

    @Override
    protected void onPostExecute(List<Post> result) {
        super.onPostExecute(result);
        adapter.clear();
        adapter.addAll(result);
    }
}
