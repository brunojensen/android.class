package com.example.persistencia;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;

public class ListActivity extends android.app.ListActivity {

    private BlogLiteHelper blogLiteHelper;
    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        blogLiteHelper = new BlogLiteHelper(getApplicationContext());
        adapter = new CustomAdapter((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE));
        BlogLoaderTask task = new BlogLoaderTask(blogLiteHelper, adapter);
        task.execute();
        setListAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
